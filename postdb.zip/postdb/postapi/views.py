from django.shortcuts import render,HttpResponse
from postapi.models import detail

# Create your views here.
def home(request):
    return render(request,'index.html')
def handledata(request):
    if request.method=="POST":
        email=request.POST['email']
        password=request.POST['password']
        print(email,password)
        ins=detail(email=email,password=password)
        ins.save()
        return HttpResponse("inserted",content_type="text/html",status=200)
    