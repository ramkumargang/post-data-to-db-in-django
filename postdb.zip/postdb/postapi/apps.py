from django.apps import AppConfig


class PostapiConfig(AppConfig):
    name = 'postapi'
